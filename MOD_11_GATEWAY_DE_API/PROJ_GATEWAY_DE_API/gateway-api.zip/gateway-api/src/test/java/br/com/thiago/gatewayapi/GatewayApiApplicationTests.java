package br.com.thiago.gatewayapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatewayApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
