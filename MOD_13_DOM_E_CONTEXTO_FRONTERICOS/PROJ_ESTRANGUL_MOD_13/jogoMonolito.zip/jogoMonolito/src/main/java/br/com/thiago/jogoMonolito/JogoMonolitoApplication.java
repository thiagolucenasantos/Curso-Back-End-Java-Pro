package br.com.thiago.jogoMonolito;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JogoMonolitoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JogoMonolitoApplication.class, args);
	}

}
