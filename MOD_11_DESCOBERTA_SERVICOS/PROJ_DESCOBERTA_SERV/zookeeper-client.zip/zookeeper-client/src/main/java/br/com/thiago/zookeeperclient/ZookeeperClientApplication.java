package br.com.thiago.zookeeperclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZookeeperClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZookeeperClientApplication.class, args);
	}

}
