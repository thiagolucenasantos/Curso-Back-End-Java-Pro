package br.com.thiago.zookeeperclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZookeeperClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
