package br.com.thiago.zookeeperserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZookeeperServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
