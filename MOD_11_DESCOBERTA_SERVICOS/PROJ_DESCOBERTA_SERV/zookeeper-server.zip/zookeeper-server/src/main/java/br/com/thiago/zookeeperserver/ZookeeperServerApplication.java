package br.com.thiago.zookeeperserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZookeeperServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZookeeperServerApplication.class, args);
	}

}
