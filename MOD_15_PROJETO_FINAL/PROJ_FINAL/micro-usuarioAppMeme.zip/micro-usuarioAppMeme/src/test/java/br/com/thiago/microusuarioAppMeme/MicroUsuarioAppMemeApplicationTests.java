package br.com.thiago.microusuarioAppMeme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroUsuarioAppMemeApplicationTests {

	@Test
	void contextLoads() {
	}

}
