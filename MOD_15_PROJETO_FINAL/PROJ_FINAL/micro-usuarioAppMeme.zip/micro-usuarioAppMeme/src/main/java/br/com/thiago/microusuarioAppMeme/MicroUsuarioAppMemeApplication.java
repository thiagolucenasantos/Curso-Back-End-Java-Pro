package br.com.thiago.microusuarioAppMeme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroUsuarioAppMemeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroUsuarioAppMemeApplication.class, args);
	}

}
