package br.com.thiago.microcategoriaMeme;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroCategoriaMemeApplicationTests {

	@Test
	void contextLoads() {
	}

}
