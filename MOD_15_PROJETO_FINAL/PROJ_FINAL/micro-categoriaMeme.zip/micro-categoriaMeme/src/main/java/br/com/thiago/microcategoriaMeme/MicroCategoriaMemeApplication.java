package br.com.thiago.microcategoriaMeme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroCategoriaMemeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroCategoriaMemeApplication.class, args);
	}

}
