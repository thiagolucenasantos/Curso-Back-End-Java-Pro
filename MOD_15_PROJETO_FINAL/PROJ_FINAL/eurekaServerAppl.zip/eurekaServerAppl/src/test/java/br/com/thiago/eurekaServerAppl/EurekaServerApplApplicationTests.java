package br.com.thiago.eurekaServerAppl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServerApplApplicationTests {

	@Test
	void contextLoads() {
	}

}
